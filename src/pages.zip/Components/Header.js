import React from "react";

const Header = () => {
  return (
    <>
      <div className="header-style-01">
        {/* support bar area end */}
        <nav className="navbar navbar-area navbar-expand-lg nav-style-02">
          <div className="container nav-container startup-nav">
            <div className="responsive-mobile-menu">
              <div className="logo-wrapper">
                <a href="/" className="logo">
                  <img src="/images/logo-02.png" alt="" />
                </a>
              </div>
              <button
                className="navbar-toggler"
                type="button"
                data-toggle="collapse"
                data-target="#bizcoxx_main_menu"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon"></span>
              </button>
            </div>
            <div className="collapse navbar-collapse" id="bizcoxx_main_menu">
              <ul className="navbar-nav">
                <li className="current-menu-item">
                  <a href="/">Home</a>
                </li>
                <li className="">
                  <a href="/contact">Contact Us</a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
        {/* navbar area end */}
        {/* Rest of your header content */}
      </div>

      <div
        className="header-area header-startup header-bg"
        // style={{ backgroundImage: `url(${bgImage})` }}
      >
        <div
          className="startup-bg-img wow animate__animated animate__zoomIn"
          data-parallax={`{"x": 220, "y": 150}`}
          // style={{ backgroundImage: "url(images/01.png)" }}
        ></div>
        <div className="shape"></div>
        <div className="shape-02"></div>
        <div className="container">
          <div className="row">
            <div className="col-lg-6">
              <div className="header-inner">
                {/* header inner */}
                <span> Best Development Metaverse Services &amp; </span>
                <h1 className="title">Metaverse Development Company </h1>
                <p>
                  METAFOCUZ one of the trusted Metaverse development company and service provider in
                  INDIA
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>

    // <div>ytuyutg</div>
  );
};

export default Header;
